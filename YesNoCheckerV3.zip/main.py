show_instructions = ""
while show_instructions.lower() != "xxx":
  # Ask user if they've played before
  show_instructions = input("Have you played this game before? ").lower()
  # If they say yes, output 'program continues' 
  if show_instructions == "yes" or show_instructions == "y":
    showinstructions = "yes"
    print("program continues")

  # If they say no, output 'display instructions'
  elif show_instructions == "no" or show_instructions =="n":
    show_instructions = "no"
    print("display instructions")
  
  else:
    print("Please answer 'yes' or 'no'")