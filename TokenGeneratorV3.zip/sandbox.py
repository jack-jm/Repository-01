import random

for item in range(0, 20):
  number = random.randint(0, 4)
  print(number, end="\t")