# Count up from one to ten...

for item in range(1, 11): 
  print(item)