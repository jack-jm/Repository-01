get_name = input("Who are you? ")
print("Hello", get_name)